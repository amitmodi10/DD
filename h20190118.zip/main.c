#include <linux/kernel.h>       
#include <linux/module.h>       
#include <linux/fs.h>
#include <linux/sched.h>
//#include <asm/uaccess.h>
#include <linux/uaccess.h>         
#include <linux/time.h>
#include<linux/init.h>
#include<linux/version.h>
#include<linux/types.h>
#include<linux/kdev_t.h>
#include<linux/cdev.h>
#include<linux/random.h>
  
#include "chardev1.h"


#define DEVICE_NAME "char_dev"



static dev_t first; 
static struct cdev c_dev; 
static struct class *cls;  
static uint16_t i;
static char ch;



static int device_open(struct inode *inode, struct file *file)
{

        printk(KERN_INFO "device_open(%p)\n", file);
return 0;
}

static int device_release(struct inode *inode, struct file *file)
{

    printk(KERN_INFO "device_release(%p,%p)\n", inode, file);

    return 0;
}


static ssize_t device_read(struct file *file,   /* see include/linux/fs.h   */
                           char __user * buffer,        /* buffer to be
                                                         * filled with data */
                           size_t length,       /* length of the buffer     */
                           loff_t * offset)
{

#ifdef DEBUG
    printk(KERN_INFO "device_read(%p,%p,%d)\n", file, buffer, length);
#endif
	uint16_t random;
	get_random_bytes(&random,sizeof(random));
	random %= 1023;
	if(ch== 'l')
		random= 64*random; 	
	printk(KERN_INFO "random number is %u",random);
	if(copy_to_user(buffer , &random, sizeof(random)))
	printk(KERN_INFO "some data missing\n");
	
	return sizeof(random);
}	
 

long device_ioctl(struct file *file,             /* ditto */
                  unsigned int ioctl_num,        /* number and param for ioctl */
                  unsigned long ioctl_param)
{

	//char *temp1;
	//char *temp2;
	//uint16_t *temp2;
    /*
     * Switch according to the ioctl called
     */
    switch (ioctl_num) {
    case IOCTL_SET_CHANNEL:
        i= ioctl_param;
	printk(KERN_INFO "channel is %d",i);
	break;

         

    case IOCTL_SET_ALIGNMENT:
        
       
//	get_user(ch,temp1);
	ch=ioctl_param;
	printk(KERN_INFO "alignment is %c",ch);
	break;

    }

    return 0;
}


struct file_operations Fops = {
        .read = device_read,
        .unlocked_ioctl = device_ioctl,
        .open = device_open,
        .release = device_release,      /* a.k.a. close */
};


//########## INITIALIZATION FUNCTION ##################
// STEP 1,2 & 3 are to be executed in this function ### 
static int __init mychar_init(void) 
{
	printk(KERN_INFO "Namaste: mychar driver registered");
	
	// STEP 1 : reserve <major, minor>
	if (alloc_chrdev_region(&first, 0, 8, "BITS-PILANI") < 0)
	{
		return -1;
	}
	
	// STEP 2 : dynamically create device node in /dev directory
    if ((cls = class_create(THIS_MODULE, "chardrv")) == NULL)
	{
		unregister_chrdev_region(first, 8);
		return -1;
	}
    if (device_create(cls, NULL, first, NULL, "adc8") == NULL)
	{
		class_destroy(cls);
		unregister_chrdev_region(first, 8);
		return -1;
	}
	
	// STEP 3 : Link fops and cdev to device node
    cdev_init(&c_dev, &Fops);
    if (cdev_add(&c_dev, first, 8) == -1)
	{
		device_destroy(cls, first);
		class_destroy(cls);
		unregister_chrdev_region(first, 8);
		return -1;
	}
	return 0;
}
 
static void __exit mychar_exit(void) 
{
	cdev_del(&c_dev);
	device_destroy(cls, first);
	class_destroy(cls);
	unregister_chrdev_region(first, 8);
	printk(KERN_INFO "Bye: mychar driver unregistered\n\n");
}
 
module_init(mychar_init);
module_exit(mychar_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("EEE G547");
MODULE_DESCRIPTION("Our First Character Driver");
