#include "chardev1.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>              /* open */
#include <unistd.h>             /* exit */
#include <sys/ioctl.h>          /* ioctl */

uint16_t return_value;
//int ioctl_set_channel(int file_desc, char *i)
int ioctl_set_channel(int file_desc, int i)
{
    int ret_val;

    ret_val = ioctl(file_desc, IOCTL_SET_CHANNEL, i);

    if (ret_val < 0) {
        printf("ioctl_set_msg failed:%d\n", ret_val);
        exit(-1);
    }
    return 0;
}

int ioctl_set_alignment(int file_desc,char ch)
{
int ret_val;

    ret_val = ioctl(file_desc, IOCTL_SET_ALIGNMENT, ch);

    if (ret_val < 0) {
        printf("ioctl_set_msg failed:%d\n", ret_val);
        exit(-1);
    }
    return 0;
}


// main function

int main()
{ 
int i,file_desc;
	char ch;
  file_desc = open("/dev/adc8", 0);
    if (file_desc < 0) {
        printf("Can't open device file: %s\n", DEVICE_FILE_NAME);
        exit(-1);
    }

printf("enter the channel from 0 to 7: ");
scanf("%d",&i);

printf("enter the value l for left or r for right:\n" );
scanf(" %c", &ch);


ioctl_set_channel(file_desc, i);
ioctl_set_alignment(file_desc, ch);

	read(file_desc,&return_value,sizeof(return_value));
	printf("adc8 10 bit value %u\n",return_value);


close(file_desc);
return 0;




}
